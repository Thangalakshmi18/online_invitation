// Get references to the heart button and ribbon elements
const heartButton = document.getElementById('heart-button');
const ribbon = document.getElementById('ribbon');

// Add click event listener to the heart button
heartButton.addEventListener('click', function() {
  // Add the 'open' class to trigger the ribbon opening animation
  ribbon.classList.add('open');

  // After the animation finishes (2 seconds), redirect to invitation.html
  setTimeout(function() {
    window.location.href = 'invitation.html';
  }, 2000); // Match the animation duration
});

// Randomize star twinkling intervals
// This code sets random animation delays for each star to create varied twinkling effects
document.addEventListener('DOMContentLoaded', function() {
  const stars = document.querySelectorAll('.star');
  stars.forEach(star => {
    const randomDelay = Math.random() * 3; // Random delay between 0 and 3 seconds
    star.style.animationDelay = randomDelay + 's';
  });
});

